# RestClient

[![Build Status](https://travis-ci.org/analyzere/RestClient.jl.png)](https://travis-ci.org/analyzere/RestClient.jl)
